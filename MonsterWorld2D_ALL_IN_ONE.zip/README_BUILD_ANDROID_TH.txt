MONSTER WORLD 2D — ANDROID BUILD KIT
====================================

สถานะ
- รวมไฟล์เกมเว็บเวอร์ชันแก้ไขไว้ใน www/
- เพิ่ม Capacitor config สำหรับสร้างแอป Android
- ZIP นี้ยังไม่ใช่ APK และยังไม่มีโฟลเดอร์ android/ เพราะต้องให้ Capacitor สร้างผ่านการติดตั้ง dependencies

สิ่งที่ต้องติดตั้งบนคอมพิวเตอร์
1. Node.js 20 ขึ้นไป (แนะนำ LTS) และ npm
2. Android Studio รุ่นปัจจุบัน
3. Android SDK Platform/Build Tools ที่ Android Studio แนะนำ
4. JDK 21 (Android Studio สามารถจัดการ JDK ที่ใช้ build ได้)

ขั้นตอนสร้าง APK (Windows PowerShell / macOS / Linux)
1. แตก ZIP นี้ลงโฟลเดอร์ที่เขียนไฟล์ได้
2. เปิด Terminal ในโฟลเดอร์ MonsterWorld2D_Android_Build_Kit
3. รัน: npm install
4. รัน: npx cap add android
5. รัน: npx cap sync android
6. รัน: npx cap open android
7. ใน Android Studio รอ Gradle Sync ให้เสร็จ แล้วเลือก Build > Build Bundle(s) / APK(s) > Build APK(s)
8. APK debug ปกติอยู่ที่ android/app/build/outputs/apk/debug/app-debug.apk

สร้าง APK ผ่าน Terminal (หลังติดตั้ง Android platform แล้ว)
- Windows: cd android; .\gradlew.bat assembleDebug
- macOS/Linux: cd android && ./gradlew assembleDebug

ทดสอบก่อนส่งต่อ
- ติดตั้ง APK บนเครื่อง Android จริง
- ทดสอบเริ่มเกม, เดินทั้ง 3 แผนที่, แตะ NPC/หีบ/ทางออก, ต่อสู้, จับมอนสเตอร์, เซฟและโหลด
- ทดสอบหมุนจอ/ขนาดหน้าจอและปุ่มย้อนกลับ

ข้อจำกัดที่ควรรู้
- ในสภาพแวดล้อมที่จัดทำ ZIP นี้ไม่มี Gradle และ Android SDK จึงยังไม่สามารถคอมไพล์หรือยืนยัน APK จริงได้
- การแตะ NPC/หีบ/ทางออกบนแผนที่ได้รับการเพิ่มตัวจัดการแล้ว แต่บางตำแหน่งอาจต้องเดินอ้อมสิ่งกีดขวาง
- เซฟใช้ localStorage ภายในแอปนี้และไม่ซิงก์ข้ามอุปกรณ์
- อย่าลบ www/ หรือเปลี่ยน webDir เว้นแต่แก้ capacitor.config.json ให้ตรงกัน
