/* Procedural pixel-art assets: no external image files required. */
const PixelAssets = (() => {
 const C={grass:"#5aa650",grassDark:"#347c43",grassLight:"#80c95e",path:"#d8b66e",pathDark:"#b58b4d",water:"#218ed0",waterLight:"#70d9f7",ink:"#17263d"};
 function sprite(w,h,fn){const c=document.createElement("canvas");c.width=w;c.height=h;const x=c.getContext("2d");x.imageSmoothingEnabled=false;fn(x);return c;}
 const palettes={Drakie:["#36baff","#1765a5","#eafaff"],Flammy:["#ff603e","#a82f36","#ffd25e"],Leafy:["#64c75a","#26773f","#c5f28a"],Aqua:["#38a9f4","#235fa7","#b8f3ff"],Golem:["#a6a9b1","#5a6475","#e4d5b8"],Shadow:["#9d69e8","#513b91","#f3c7ff"]};
 function monster(name,frame=0){const p=palettes[name]||palettes.Drakie;return sprite(32,32,x=>{let bob=frame===1?1:0,shift=frame===2?2:0;x.fillStyle=p[1];x.fillRect(7+shift,11+bob,18,15);x.fillRect(4+shift,15+bob,5,8);x.fillRect(23+shift,15+bob,5,8);x.fillStyle=p[0];x.fillRect(8+shift,8+bob,16,14);x.fillRect(11+shift,5+bob,4,5);x.fillRect(20+shift,5+bob,4,5);x.fillStyle=p[2];x.fillRect(10+shift,12+bob,4,5);x.fillRect(19+shift,12+bob,4,5);x.fillStyle=C.ink;x.fillRect(11+shift,13+bob,2,3);x.fillRect(20+shift,13+bob,2,3);x.fillStyle=p[2];x.fillRect(14+shift,19+bob,5,2);x.fillStyle=p[1];x.fillRect(9+shift,25+bob,5,4);x.fillRect(19+shift,25+bob,5,4);if(name==="Flammy"){x.fillStyle="#ffd25e";x.fillRect(25+shift,20,4,5);x.fillRect(27+shift,16,3,5)}if(name==="Leafy"){x.fillStyle="#8be06c";x.fillRect(3,5,7,4);x.fillRect(4,3,4,4)}if(name==="Golem"){x.fillStyle="#d6d8de";x.fillRect(4,7,6,5);x.fillRect(22,7,6,5)}if(name==="Shadow"){x.fillStyle="#3a286b";x.fillRect(6,7,4,5);x.fillRect(22,7,4,5)}if(frame===2){x.fillStyle="#fff3a6";x.fillRect(28,10,3,3);x.fillRect(29,14,2,2)}});}
 function player(frame=0,direction="down"){
  return sprite(16,20,x=>{
   const step=frame%2, side=direction==="left"||direction==="right", back=direction==="up";
   x.fillStyle="#293b65";x.fillRect(4,7,8,8);
   x.fillStyle="#f1bd8c";x.fillRect(4,4,8,7);
   x.fillStyle="#d83e4e";
   if(back){x.fillRect(3,2,10,5);x.fillRect(5,0,6,3)}
   else if(direction==="left"){x.fillRect(3,2,10,4);x.fillRect(4,0,6,3)}
   else if(direction==="right"){x.fillRect(3,2,10,4);x.fillRect(6,0,6,3)}
   else{x.fillRect(3,2,10,4);x.fillRect(5,0,6,3)}
   if(!back){x.fillStyle=C.ink;if(direction==="left")x.fillRect(5,6,2,2);else if(direction==="right")x.fillRect(9,6,2,2);else{x.fillRect(6,6,1,2);x.fillRect(10,6,1,2)}}
   x.fillStyle="#e8f2ff";x.fillRect(3,12,10,4);
   x.fillStyle="#344b75";
   if(side){x.fillRect(direction==="left"?4:9,15,3,5);x.fillRect(direction==="left"?8:4,16+(step?1:0),3,4)}
   else{x.fillRect(step?3:4,16,3,4);x.fillRect(step?10:9,16,3,4)}
  });
 }
 function npc(kind){return sprite(16,20,x=>{x.fillStyle=kind==="Mira"?"#a85fca":"#267a83";x.fillRect(3,8,10,9);x.fillStyle="#f0bd8b";x.fillRect(4,3,8,7);x.fillStyle=kind==="Mira"?"#5b3479":"#5a3a24";x.fillRect(3,2,10,3);x.fillStyle="#18263c";x.fillRect(6,6,1,2);x.fillRect(10,6,1,2);x.fillStyle="#e8f2ff";x.fillRect(4,17,3,3);x.fillRect(9,17,3,3)});}
 function tree(){return sprite(24,28,x=>{x.fillStyle="#70482c";x.fillRect(10,15,5,12);x.fillStyle="#236b3c";x.fillRect(4,7,16,13);x.fillRect(7,3,11,14);x.fillStyle="#4bb95b";x.fillRect(6,6,5,5);x.fillRect(13,4,5,6);x.fillRect(10,12,6,4)});}
 function rock(){return sprite(16,16,x=>{x.fillStyle="#586779";x.fillRect(3,7,10,7);x.fillRect(5,4,6,4);x.fillStyle="#aab9c5";x.fillRect(5,5,4,2);x.fillStyle="#354456";x.fillRect(4,12,8,2)});}
 function drawTile(ctx,x,y,type,seed=0){
  const speck=(col,px,py,w=2,h=2)=>{ctx.fillStyle=col;ctx.fillRect(x+px,y+py,w,h)};
  if(type==="water"){ctx.fillStyle="#218ed0";ctx.fillRect(x,y,16,16);speck("#70d9f7",(seed%7)+2,4,5,1);speck("#1674b7",(seed%5)+7,11,4,1);if(seed%3===0)speck("#b4f0ff",4,8,2,1)}
  else if(type==="path"||type==="sand"){ctx.fillStyle=type==="sand"?"#e8cf86":C.path;ctx.fillRect(x,y,16,16);speck(C.pathDark,3+(seed%5),4,2,2);if(seed%4===0)speck("#f5dfa0",10,11,3,1)}
  else if(type==="stone"){ctx.fillStyle="#788796";ctx.fillRect(x,y,16,16);speck("#9eabb8",2,3,5,2);speck("#536273",9,10,4,2)}
  else if(type==="bridge"){ctx.fillStyle="#218ed0";ctx.fillRect(x,y,16,16);ctx.fillStyle="#98643d";ctx.fillRect(0+x, y+2,16,12);ctx.fillStyle="#d6a66a";for(let i=1;i<16;i+=4)ctx.fillRect(x+i,y+2,1,12);ctx.fillStyle="#70482c";ctx.fillRect(x,y+1,16,2);ctx.fillRect(x,y+13,16,2)}
  else if(type==="flower"){ctx.fillStyle=C.grass;ctx.fillRect(x,y,16,16);speck(C.grassDark,2,10,2,2);speck("#ffdc6b",6,5,3,3);speck("#fff1bc",5,4,2,2);if(seed%2===0)speck("#f49ab8",12,9,2,2)}
  else if(type==="tallgrass"){ctx.fillStyle=C.grass;ctx.fillRect(x,y,16,16);speck("#2d8047",3,5,2,7);speck("#86d96b",5,3,2,7);speck("#347c43",10,7,2,6);speck("#9be274",12,5,2,6)}
  else{ctx.fillStyle=C.grass;ctx.fillRect(x,y,16,16);if(seed%4===0)speck(C.grassDark,2,4,2,2);if(seed%5===0)speck(C.grassDark,11,10,2,2);if(seed%6===0)speck(C.grassLight,7,2,2,2)}
 }

 // Load real PNG assets asynchronously; keep procedural drawing as a safe fallback.
 const loaded = Object.create(null);
 function loadPNG(key, path){ const im=new Image(); im.onload=()=>{loaded[key]=im;}; im.onerror=()=>{}; im.src=path; }
 loadPNG("playerSheet","assets/Characters/player_spritesheet.png");
 loadPNG("slimeSheet","assets/Monsters/slime_spritesheet.png");
 loadPNG("blueSlimeSheet","assets/Monsters/blue_slime_spritesheet.png");
 loadPNG("fireSlimeSheet","assets/Monsters/fire_slime_spritesheet.png");
 loadPNG("batSheet","assets/Monsters/bat_spritesheet.png");
 loadPNG("treePNG","assets/Props/tree.png");
 loadPNG("grassTile","assets/Tileset/tile_grass.png");
 loadPNG("dirtTile","assets/Tileset/tile_dirt.png");
 loadPNG("stoneTile","assets/Tileset/tile_stone.png");
 loadPNG("waterTile","assets/Tileset/tile_water.png");
 loadPNG("lavaTile","assets/Tileset/tile_lava.png");
 loadPNG("backgroundDay","assets/Background/bg_day.png");
 loadPNG("backgroundSunset","assets/Background/bg_sunset.png");
 loadPNG("backgroundNight","assets/Background/bg_night.png");
 loadPNG("itemCoin","assets/Items/coin.png");
 loadPNG("itemPotion","assets/Items/potion.png");
 loadPNG("itemHeart","assets/Items/heart.png");
 loadPNG("itemKey","assets/Items/key.png");
 loadPNG("itemGem","assets/Items/gem.png");
 loadPNG("itemChest","assets/Items/chest.png");
 loadPNG("weaponSword","assets/Weapons/sword.png");
 loadPNG("effectSlash","assets/Effects/magic_slash.png");
 loadPNG("uiHeart","assets/UI/heart_icon.png");
 loadPNG("uiButton","assets/UI/button_blue.png");
 function cropSprite(key, frame, fw, fh, outW, outH, fallback){
   const im=loaded[key]; if(!im) return fallback();
   return sprite(outW,outH,x=>{x.imageSmoothingEnabled=false;x.drawImage(im,Math.max(0,frame)*fw,0,fw,fh,0,0,outW,outH);});
 }
 const oldMonster=monster, oldPlayer=player, oldTree=tree, oldDrawTile=drawTile;
 monster=function(name,frame=0){
   let key="slimeSheet";
   if(name==="Flammy"||name==="fire_slime") key="fireSlimeSheet";
   else if(name==="Aqua"||name==="Drakie") key="blueSlimeSheet";
   else if(name==="Shadow") key="batSheet";
   return cropSprite(key,frame%4,64,64,32,32,()=>oldMonster(name,frame));
 };
 player=function(frame=0,direction="down"){
   // The supplied hero sheet has 8 horizontal 64px frames; scale to the game's 16x20 actor size.
   return cropSprite("playerSheet",frame%8,64,64,16,20,()=>oldPlayer(frame,direction));
 };
 tree=function(){return cropSprite("treePNG",0,64,64,24,28,oldTree);};
 drawTile=function(ctx,x,y,type,seed=0){
   const key=({grass:"grassTile",path:"dirtTile",sand:"dirtTile",stone:"stoneTile",water:"waterTile",lava:"lavaTile"})[type];
   const im=key&&loaded[key];
   if(im){ctx.imageSmoothingEnabled=false;ctx.drawImage(im,x,y,16,16);return;}
   return oldDrawTile(ctx,x,y,type,seed);
 };
 function imageSprite(key, outW=16, outH=16, fallbackColor="#e8f2ff"){
   const im=loaded[key];
   if(!im) return sprite(outW,outH,x=>{x.fillStyle=fallbackColor;x.fillRect(2,2,outW-4,outH-4);});
   return sprite(outW,outH,x=>{x.imageSmoothingEnabled=false;x.drawImage(im,0,0,im.width,im.height,0,0,outW,outH);});
 }
 function item(name, outW=16, outH=16){
   const keys={coin:"itemCoin",potion:"itemPotion",herb:"itemGem",crystal:"itemGem",key:"itemKey",chest:"itemChest",heart:"itemHeart",sword:"weaponSword",slash:"effectSlash"};
   const colors={coin:"#f4c542",potion:"#cf5dba",herb:"#68c65c",crystal:"#62d8f0",key:"#f0d36d",chest:"#a56a38",heart:"#ef5268",sword:"#d7e8f4",slash:"#e7f4ff"};
   return imageSprite(keys[name]||"itemCoin",outW,outH,colors[name]||"#e8f2ff");
 }
 function drawBackground(ctx, type="day", x=0,y=0,w=320,h=180){
   const key=type==="night"?"backgroundNight":type==="sunset"?"backgroundSunset":"backgroundDay";
   const im=loaded[key]; if(im){ctx.imageSmoothingEnabled=false;ctx.drawImage(im,x,y,w,h);return true;} return false;
 }
 return {monster,player,npc,tree,rock,drawTile,drawBackground,item,loaded};
})();