(() => {
"use strict";
const SAVE_KEY="mw2d_v3_save";
const canvas=document.getElementById("game"),ctx=canvas.getContext("2d");
ctx.imageSmoothingEnabled=false;
const TILE=16, W=20, H=15;
const species=[{name:"Drakie",hp:22,atk:7},{name:"Flammy",hp:20,atk:8},{name:"Leafy",hp:24,atk:6},{name:"Aqua",hp:23,atk:7},{name:"Golem",hp:30,atk:5},{name:"Shadow",hp:19,atk:9}];
const maps={
 village:{label:"หมู่บ้านเริ่มต้น",type:"village",tiles:makeMap("village"),start:{x:9,y:8},exits:[{x:18,y:7,to:"meadow",tx:2,ty:7,label:"ทางไปทุ่งหญ้า"}]},
 meadow:{label:"ทุ่งหญ้าสายลม",type:"meadow",tiles:makeMap("meadow"),start:{x:2,y:7},exits:[{x:18,y:7,to:"village",tx:17,ty:7,label:"กลับหมู่บ้าน"},{x:18,y:12,to:"forest",tx:2,ty:12,label:"ทางไปป่าลึก"}]},
 forest:{label:"ป่าลึกเงาจันทร์",type:"forest",tiles:makeMap("forest"),start:{x:2,y:12},exits:[{x:18,y:12,to:"meadow",tx:17,ty:12,label:"กลับทุ่งหญ้า"}]}
};
function makeMap(type){
 let a=Array.from({length:H},(_,y)=>Array.from({length:W},(_,x)=>((x===0||y===0||x===W-1||y===H-1)?"water":"grass")));
 const line=(x1,y1,x2,y2,t="path")=>{let x=x1,y=y1;while(true){if(x>0&&x<W-1&&y>0&&y<H-1)a[y][x]=t;if(x===x2&&y===y2)break;if(x<x2)x++;else if(x>x2)x--;else if(y<y2)y++;else if(y>y2)y--;}};
 if(type==="village"){
  line(2,7,17,7);line(9,2,9,13);line(3,10,9,10);line(13,7,13,12);
  for(let y=2;y<5;y++)for(let x=3;x<6;x++)a[y][x]="stone";
  for(let y=2;y<5;y++)for(let x=14;x<17;x++)a[y][x]="stone";
  a[6][17]="path";a[7][18]="path";
 }else if(type==="meadow"){
  line(1,7,18,7);line(10,3,10,12);line(10,12,18,12);line(4,7,4,11);
  for(let y=2;y<13;y++)for(let x=2;x<18;x++)if(a[y][x]==="grass"&&((x*13+y*7)%9===0))a[y][x]="tallgrass";
  for(let x=6;x<9;x++)a[7][x]="bridge";
  a[18][7]="path";a[18][12]="path";
 }else{
  line(2,12,17,12);line(10,3,10,12);line(10,3,16,3);line(16,3,16,7);
  for(let y=2;y<13;y++)for(let x=2;x<18;x++)if(a[y][x]==="grass"&&((x*5+y*11)%6===0))a[y][x]="flower";
  for(let y=3;y<12;y++)for(let x=3;x<18;x++)if(a[y][x]==="grass"&&((x*17+y*19)%13===0))a[y][x]="tallgrass";
  a[18][12]="path";
 }
 return a;
}
const npcList={
 village:[{id:"mira",name:"มีร่า",kind:"Mira",x:6,y:6,quest:"herbs",text:"ช่วยเก็บสมุนไพร 3 ชิ้นจากหีบในทุ่งหญ้าให้หน่อยนะ"} ,{id:"guard",name:"ยามต้น",kind:"Guard",x:12,y:8,quest:"catch",text:"นักผจญภัย! จับมอนสเตอร์ป่า 1 ตัว แล้วกลับมารายงานข้า"}],
 meadow:[{id:"herbalist",name:"นักปรุงยา",kind:"Mira",x:5,y:5,quest:"battle",text:"กำจัดมอนสเตอร์ป่า 2 ตัวเพื่อพิสูจน์ฝีมือ"}],
 forest:[{id:"sage",name:"ผู้เฒ่าป่า",kind:"Guard",x:8,y:6,quest:"forest",text:"เก็บผลึกป่า 2 ชิ้นจากหีบในป่าลึก"}]
};
const chestList={
 meadow:[{id:"herb1",x:7,y:4,item:"herb",amount:1},{id:"herb2",x:13,y:9,item:"herb",amount:1},{id:"herb3",x:15,y:4,item:"herb",amount:1},{id:"potion1",x:4,y:11,item:"potion",amount:1}],
 forest:[{id:"crystal1",x:5,y:9,item:"crystal",amount:1},{id:"crystal2",x:14,y:5,item:"crystal",amount:1},{id:"coin1",x:12,y:10,item:"coin",amount:12}],
 village:[{id:"starter",x:3,y:10,item:"potion",amount:1}]
};
function id(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function freshMonster(name,level=1,hp=null){let s=species.find(v=>v.name===name)||species[0],max=s.hp+(level-1)*2;return {uid:id(),name,level,max,hp:hp===null?max:Math.min(max,hp)}}
let state={map:"village",player:{x:9,y:8,hp:30,max:30,level:1,xp:0,coins:10,potions:3,captureBalls:5},team:[freshMonster("Drakie"),freshMonster("Flammy"),freshMonster("Leafy")],active:null,inventory:{herb:0,crystal:0,potion:3},opened:[],quests:{herbs:{accepted:false,done:false},catch:{accepted:false,done:false},battle:{accepted:false,done:false},forest:{accepted:false,done:false}},stats:{caught:0,won:0},steps:0};
state.active=state.team[0].uid;
let enemy=null,inBattle=false,toastTimer=null,frame=0,turn=0,facing="down";
const byId=x=>document.getElementById(x);
function say(s){byId("toast").textContent=s;byId("toast").style.display="block";clearTimeout(toastTimer);toastTimer=setTimeout(()=>{if(!inBattle)byId("toast").style.display="none"},3200)}
function active(){return state.team.find(m=>m.uid===state.active)||state.team.find(m=>m.hp>0)||state.team[0]}
function getSpecies(n){return species.find(s=>s.name===n)||species[0]}
function near(a,b){return Math.abs(a.x-b.x)+Math.abs(a.y-b.y)<=1}
function currentMap(){return maps[state.map]}
function render(){
 const p=state.player;byId("playerLevel").textContent=`นักผจญภัย Lv.${p.level}`;byId("playerHp").textContent=`HP ${p.hp}/${p.max}`;byId("hpBar").style.width=100*p.hp/p.max+"%";
 byId("coins").textContent=`เหรียญ ${p.coins}`;byId("potions").textContent=`ยา ${state.inventory.potion}`;byId("potions2").textContent=`ลูกบอลจับ ${p.captureBalls}`;
 byId("xpText").textContent=`XP ${p.xp}/${p.level*20}`;byId("xpBar").style.width=100*p.xp/(p.level*20)+"%";
 byId("mapLabel").textContent=currentMap().label;
 const team=byId("team");team.innerHTML="";
 state.team.forEach(m=>{let b=document.createElement("button");b.className="mon-card"+(m.uid===state.active?" active":"");b.innerHTML=`<b>${m.name}</b><br>Lv.${m.level}<br>HP ${m.hp}/${m.max}`;b.onclick=()=>{if(m.hp<=0){say("ตัวนี้หมดแรง ต้องพักฟื้นก่อน");return}state.active=m.uid;render();draw();say("เลือก "+m.name)};team.appendChild(b)});
 const qNames={herbs:"เก็บสมุนไพร 3 ชิ้น",catch:"จับมอนสเตอร์ 1 ตัว",battle:"ชนะการต่อสู้ 2 ครั้ง",forest:"เก็บผลึกป่า 2 ชิ้น"};
 byId("quests").innerHTML=Object.keys(state.quests).map(k=>{let q=state.quests[k],progress=questProgress(k);return `<div class="quest"><b>${qNames[k]}</b><br>${q.done?'<span class="done">สำเร็จแล้ว ✓</span>':q.accepted?progress:"ยังไม่รับ — คุยกับ NPC"}</div>`}).join("");
 const items=[["herb","สมุนไพร"],["crystal","ผลึกป่า"],["potion","ยา"],["captureBalls","ลูกบอลจับ"],["coins","เหรียญ"]];
 byId("inventory").innerHTML=items.map(([k,label])=>{const icon=k==="coins"?"coin":k==="potion"?"potion":k==="herb"?"herb":k==="crystal"?"crystal":"key";const count=k==="captureBalls"?state.player.captureBalls:k==="coins"?state.player.coins:state.inventory[k]||0;return `<div class="inventory-item"><img src="assets/Items/${icon}.png" alt="" onerror="this.style.display='none'"><span>${label}: ${count}</span></div>`}).join("");
 byId("battlePanel").classList.toggle("hidden",!inBattle);
 byId("enemyInfo").textContent=enemy?`${enemy.name} Lv.${enemy.level} — HP ${enemy.hp}/${enemy.max}`:"";
 byId("battleTurn").textContent=`เทิร์น ${turn}`;
 byId("catch").disabled=!inBattle||state.player.captureBalls<=0||state.team.length>=6;
}
function questProgress(k){if(k==="herbs")return `ความคืบหน้า ${state.inventory.herb}/3`;if(k==="catch")return `ความคืบหน้า ${state.stats.caught}/1`;if(k==="battle")return `ความคืบหน้า ${state.stats.won}/2`;if(k==="forest")return `ความคืบหน้า ${state.inventory.crystal}/2`;return ""}
function draw(){
 ctx.clearRect(0,0,320,240);let map=currentMap();
 for(let y=0;y<H;y++)for(let x=0;x<W;x++)PixelAssets.drawTile(ctx,x*TILE,y*TILE,map.tiles[y][x],x*3+y*7);
 // Trees and rocks use fixed coordinates so visuals and collision match.
 for(let y=2;y<H-1;y++)for(let x=2;x<W-1;x++){
  if(isTreeAt(x,y))ctx.drawImage(PixelAssets.tree(),x*TILE-4,y*TILE-10);
  else if(isRockAt(x,y))ctx.drawImage(PixelAssets.rock(),x*TILE,y*TILE);
 }
 // NPCs
 (npcList[state.map]||[]).forEach(n=>{ctx.drawImage(PixelAssets.npc(n.kind),n.x*TILE,n.y*TILE-3);ctx.fillStyle="#fff4b2";ctx.font="bold 9px system-ui";ctx.fillText("!",n.x*TILE+6,n.y*TILE-5)});
 // chests
 (chestList[state.map]||[]).forEach(c=>{if(!state.opened.includes(c.id)){ctx.drawImage(PixelAssets.item("chest",16,16),c.x*TILE,c.y*TILE,16,16)}});
 // exits
 map.exits.forEach(e=>{ctx.fillStyle="#d5efff";ctx.fillRect(e.x*TILE+3,e.y*TILE+2,10,12);ctx.fillStyle="#3977a7";ctx.fillRect(e.x*TILE+6,e.y*TILE+5,4,9)});
 if(!inBattle){ctx.drawImage(PixelAssets.player(frame%2,facing),state.player.x*TILE,state.player.y*TILE-3);return}
 ctx.fillStyle="#0c1930";ctx.fillRect(0,0,320,240);
 // Battle arena uses the real background PNG when loaded, with the original canvas scene as fallback.
 if(!PixelAssets.drawBackground(ctx,state.map==="forest"?"night":state.map==="meadow"?"sunset":"day",0,0,320,130)){
   ctx.fillStyle="#1a3a59";ctx.fillRect(8,12,304,108);ctx.fillStyle="#76c8e7";ctx.fillRect(15,19,290,94);ctx.fillStyle="#5aa650";ctx.fillRect(15,66,290,47);ctx.fillStyle="#3e8748";ctx.fillRect(15,66,290,3);
 } else {ctx.fillStyle="#5aa650";ctx.fillRect(15,66,290,47);ctx.fillStyle="#3e8748";ctx.fillRect(15,66,290,3);}
 if(enemy)ctx.drawImage(PixelAssets.monster(enemy.name,turn%2),220,28,64,64);let m=active();if(m)ctx.drawImage(PixelAssets.monster(m.name,frame%2),35,65,64,64);
 // Weapon/effect assets are rendered briefly as a visual accent on the player's battle side.
 if(turn>0&&turn%2===0){ctx.drawImage(PixelAssets.item("sword",20,20),94,91,20,20);ctx.drawImage(PixelAssets.item("slash",24,24),111,77,24,24);}
 ctx.fillStyle="#10203a";ctx.fillRect(160,12,146,40);ctx.fillStyle="#fff";ctx.font="bold 10px system-ui";ctx.fillText(enemy?`${enemy.name} Lv.${enemy.level}`:"",167,26);ctx.fillStyle="#3d506a";ctx.fillRect(167,32,130,7);if(enemy){ctx.fillStyle="#49dc8d";ctx.fillRect(167,32,130*enemy.hp/enemy.max,7)}
 ctx.fillStyle="#10203a";ctx.fillRect(10,145,300,80);ctx.fillStyle="#f4f7ff";ctx.font="bold 11px system-ui";ctx.fillText(m?`${m.name} Lv.${m.level}`:"ทีม",20,161);if(m){ctx.fillText(`HP ${m.hp}/${m.max}`,20,177);ctx.fillStyle="#3d506a";ctx.fillRect(20,184,120,7);ctx.fillStyle="#49dc8d";ctx.fillRect(20,184,120*m.hp/m.max,7)}ctx.fillStyle="#f4f7ff";ctx.font="10px system-ui";ctx.fillText("เลือกคำสั่งจากปุ่มต่อสู้",20,210);
}
function specialAt(x,y){
 const mapKey=state.map;
 return (npcList[mapKey]||[]).some(n=>n.x===x&&n.y===y) ||
  (chestList[mapKey]||[]).some(c=>c.x===x&&c.y===y) ||
  currentMap().exits.some(e=>e.x===x&&e.y===y) ||
  (maps[mapKey].start.x===x&&maps[mapKey].start.y===y);
}
function isTreeAt(x,y){return currentMap().tiles[y]?.[x]==="grass"&&!specialAt(x,y)&&!isRockAtRaw(x,y)&&((x*7+y*11+(state.map==="forest"?3:0))%29===0)}
function isRockAtRaw(x,y){return ((x*17+y*23)%37===0)}
function isRockAt(x,y){return currentMap().tiles[y]?.[x]==="grass"&&!specialAt(x,y)&&isRockAtRaw(x,y)&&!isTreeAtRaw(x,y)}
function isTreeAtRaw(x,y){return ((x*7+y*11+(state.map==="forest"?3:0))%29===0)}
function passable(x,y){
 if(x<1||y<1||x>W-2||y>H-2)return false;
 if(["water","stone"].includes(currentMap().tiles[y][x]))return false;
 if(isTreeAt(x,y)||isRockAt(x,y))return false;
 if((npcList[state.map]||[]).some(n=>n.x===x&&n.y===y))return false;
 return true;
}
function move(dx,dy){if(inBattle)return;if(dx<0)facing="left";else if(dx>0)facing="right";else if(dy<0)facing="up";else if(dy>0)facing="down";let p=state.player,nx=p.x+dx,ny=p.y+dy;if(!passable(nx,ny)){say("ทางนี้ไปไม่ได้");return}p.x=nx;p.y=ny;frame++;state.steps++;
 let exit=currentMap().exits.find(e=>e.x===nx&&e.y===ny);if(exit){state.map=exit.to;p.x=exit.tx;p.y=exit.ty;byId("mapLabel").textContent=currentMap().label;say("เข้าสู่"+currentMap().label);draw();render();autoSave();return}
 const chest=(chestList[state.map]||[]).find(c=>c.x===nx&&c.y===ny&&!state.opened.includes(c.id));if(chest){openChest(chest);return}
 const npc=(npcList[state.map]||[]).find(n=>n.x===nx&&n.y===ny);if(npc){talk(npc);return}
 draw();if(currentMap().type!=="village"&&currentMap().tiles[ny][nx]==="grass"&&Math.random()<.17)encounter();if(state.steps%8===0)autoSave()
}
function interact(){let p=state.player;const npc=(npcList[state.map]||[]).find(n=>near(p,n));if(npc){talk(npc);return}const chest=(chestList[state.map]||[]).find(c=>near(p,c)&&!state.opened.includes(c.id));if(chest){openChest(chest);return}const exit=currentMap().exits.find(e=>near(p,e));if(exit){state.map=exit.to;p.x=exit.tx;p.y=exit.ty;draw();render();say("เดินทางไป"+currentMap().label);autoSave();return}say("ไม่มีอะไรให้โต้ตอบใกล้ ๆ")}
function talk(n){let q=state.quests[n.quest];if(!q){say(`${n.name}: ${n.text}`);return}if(!q.accepted&&!q.done){if(confirm(`${n.name}: ${n.text}\nรับภารกิจนี้หรือไม่?`)){q.accepted=true;render();say("รับภารกิจแล้ว: "+n.text);autoSave()}return}if(q.accepted&&!q.done&&questReady(n.quest)){q.done=true;let reward=questReward(n.quest);state.player.coins+=reward.coins;state.inventory.potion+=reward.potions;state.player.captureBalls+=reward.balls;render();say(`ภารกิจสำเร็จ! ได้ ${reward.coins} เหรียญ`);autoSave();return}say(q.done?`${n.name}: ขอบใจมาก ภารกิจสำเร็จแล้ว!`:`${n.name}: ${n.text}`)}
function questReady(k){if(k==="herbs")return state.inventory.herb>=3;if(k==="catch")return state.stats.caught>=1;if(k==="battle")return state.stats.won>=2;if(k==="forest")return state.inventory.crystal>=2;return false}
function questReward(k){if(k==="herbs"){state.inventory.herb-=3;return {coins:15,potions:2,balls:0}}if(k==="catch")return {coins:20,potions:1,balls:3};if(k==="battle")return {coins:25,potions:2,balls:0};state.inventory.crystal-=2;return {coins:35,potions:1,balls:2}}
function openChest(c){state.opened.push(c.id);if(c.item==="herb")state.inventory.herb+=c.amount;if(c.item==="crystal")state.inventory.crystal+=c.amount;if(c.item==="potion")state.inventory.potion+=c.amount;if(c.item==="coin")state.player.coins+=c.amount;render();draw();let label={herb:"สมุนไพร",crystal:"ผลึกป่า",potion:"ยา",coin:"เหรียญ"}[c.item];say(`เปิดหีบ! ได้${label} ${c.amount}`);autoSave()}
function encounter(){let pool=state.map==="forest"?["Golem","Shadow","Leafy","Shadow"]:["Drakie","Flammy","Leafy","Aqua"];let name=pool[Math.floor(Math.random()*pool.length)],s=getSpecies(name),level=1+Math.floor(Math.random()*3),max=s.hp+(level-1)*2;enemy={uid:id(),name,level,max,hp:max};inBattle=true;turn=1;render();draw();say("พบมอนสเตอร์ป่า! เลือกคำสั่งต่อสู้")}
function enemyAttack(){if(!inBattle)return;let m=active();if(!m)return;let dmg=2+Math.floor(Math.random()*5)+enemy.level;m.hp=Math.max(0,m.hp-dmg);turn++;if(m.hp<=0){let next=state.team.find(v=>v.hp>0);if(next){state.active=next.uid;say(`${m.name} หมดแรง! ส่ง ${next.name} ลงสนาม`)}else{state.team.forEach(v=>v.hp=v.max);state.player.hp=Math.max(1,state.player.hp-5);say("ทีมหมดแรง พักฟื้นทีมแล้ว")}}render();draw()}
function finishWin(){let e=enemy,m=active();state.player.coins+=5+e.level*2;state.player.xp+=8+e.level*4;state.stats.won++;if(m){m.level+=1;m.max+=2;m.hp=Math.min(m.max,m.hp+5)}while(state.player.xp>=state.player.level*20){state.player.xp-=state.player.level*20;state.player.level++;state.player.max+=5;state.player.hp=state.player.max}inBattle=false;enemy=null;render();draw();say("ชนะการต่อสู้! ได้เหรียญและ XP");autoSave()}
function attack(){if(!inBattle||!enemy)return;let m=active();if(!m||m.hp<=0){say("เลือกมอนสเตอร์ที่ยังมี HP");return}let dmg=getSpecies(m.name).atk+m.level+Math.floor(Math.random()*4);enemy.hp=Math.max(0,enemy.hp-dmg);turn++;if(enemy.hp<=0){finishWin();return}render();draw();enemyAttack()}
function catchEnemy(){if(!inBattle||!enemy)return;if(state.player.captureBalls<=0){say("ลูกบอลจับหมดแล้ว");return}if(state.team.length>=6){say("ทีมเต็ม 6 ตัวแล้ว");return}state.player.captureBalls--;let chance=Math.max(.18,Math.min(.88,.78-.6*(enemy.hp/enemy.max)));if(Math.random()<chance){let m=freshMonster(enemy.name,enemy.level,Math.ceil(enemy.max*.7));state.team.push(m);state.active=m.uid;state.stats.caught++;inBattle=false;enemy=null;render();draw();say("จับมอนสเตอร์สำเร็จ!");autoSave()}else{say("จับไม่สำเร็จ!");enemyAttack()}}
function usePotionBattle(){if(!inBattle)return;usePotion(true)}
function usePotion(inBattleUse=false){if(state.inventory.potion<=0){say("ยาไม่เหลือแล้ว");return}let m=active();if(!m){say("ไม่มีมอนสเตอร์");return}if(m.hp>=m.max){say("HP เต็มแล้ว");return}state.inventory.potion--;m.hp=Math.min(m.max,m.hp+12);render();draw();say("ใช้ยา ฟื้น HP 12");if(inBattleUse&&inBattle)enemyAttack();autoSave()}
function switchBattle(){if(!inBattle)return;let i=state.team.findIndex(m=>m.uid===state.active);for(let n=1;n<=state.team.length;n++){let m=state.team[(i+n)%state.team.length];if(m.hp>0){state.active=m.uid;render();draw();say("สลับเป็น "+m.name);enemyAttack();return}}say("ไม่มีมอนสเตอร์พร้อมต่อสู้")}
function run(){if(inBattle){inBattle=false;enemy=null;render();draw();say("หนีสำเร็จ");}}
function switchTeam(){let i=state.team.findIndex(m=>m.uid===state.active);for(let n=1;n<=state.team.length;n++){let m=state.team[(i+n)%state.team.length];if(m.hp>0){state.active=m.uid;render();draw();say("เลือก "+m.name);return}}}
function healTeam(){if(state.player.coins<8){say("เหรียญไม่พอ ต้องใช้ 8 เหรียญ");return}state.player.coins-=8;state.team.forEach(m=>m.hp=m.max);state.player.hp=state.player.max;render();draw();say("ทีมพักฟื้นเต็ม HP แล้ว");autoSave()}
function buyBall(){if(state.player.coins<5){say("เหรียญไม่พอ");return}state.player.coins-=5;state.player.captureBalls++;render();say("ซื้อบอลจับ 1 ลูก");autoSave()}
function save(){try{let data=JSON.stringify({...state,saveVersion:3,savedAt:new Date().toISOString()});localStorage.setItem(SAVE_KEY,data);say("บันทึกเกมสำเร็จ");return true}catch(e){say("บันทึกไม่ได้: localStorage ใช้งานไม่ได้");return false}}
function autoSave(){try{localStorage.setItem(SAVE_KEY,JSON.stringify({...state,saveVersion:3,savedAt:new Date().toISOString()}))}catch(e){}}
function load(){try{
 const raw=localStorage.getItem(SAVE_KEY);if(!raw){say("ยังไม่มีเซฟเกม");return}
 const d=JSON.parse(raw);if(!d||d.saveVersion!==3||!d.player||!Array.isArray(d.team))throw Error("invalid save");
 state={...state,...d};
 if(!maps[state.map])state.map="village";
 state.player={map:state.map,x:9,y:8,hp:30,max:30,level:1,xp:0,coins:10,potions:3,captureBalls:5,...(d.player||{})};
 state.inventory={herb:0,crystal:0,potion:state.player.potions||0,...(d.inventory||{})};
 state.quests={herbs:{accepted:false,done:false},catch:{accepted:false,done:false},battle:{accepted:false,done:false},forest:{accepted:false,done:false},...(d.quests||{})};
 state.stats={caught:0,won:0,...(d.stats||{})};
 state.opened=Array.isArray(d.opened)?d.opened.filter(v=>typeof v==="string"):[];
 state.team=state.team.filter(m=>m&&species.some(s=>s.name===m.name)).slice(0,6).map(m=>{
   const s=getSpecies(m.name),level=Math.max(1,Math.min(99,Number(m.level)||1)),max=Math.max(1,Number(m.max)||s.hp+(level-1)*2);
   return {...m,uid:typeof m.uid==="string"?m.uid:id(),level,max,hp:Math.max(0,Math.min(max,Number(m.hp)||0))};
 });
 if(!state.team.length)state.team=[freshMonster("Drakie")];
 state.player.max=Math.max(1,Number(state.player.max)||30);
 state.player.hp=Math.max(0,Math.min(state.player.max,Number(state.player.hp)||0));
 for(const k of ["level","xp","coins","captureBalls"])state.player[k]=Math.max(0,Number(state.player[k])||0);
 state.player.level=Math.max(1,state.player.level);
 state.player.x=Math.max(1,Math.min(W-2,Number(state.player.x)||9));
 state.player.y=Math.max(1,Math.min(H-2,Number(state.player.y)||8));
 for(const k of ["herb","crystal","potion"])state.inventory[k]=Math.max(0,Number(state.inventory[k])||0);
 if(!state.team.some(m=>m.uid===state.active&&m.hp>0))state.active=(state.team.find(m=>m.hp>0)||state.team[0]).uid;
 inBattle=false;enemy=null;render();draw();say("โหลดเซฟสำเร็จ");
 }catch(e){say("เซฟเสียหายหรือเป็นเวอร์ชันเก่า")}}
function reset(){if(!confirm("เริ่มเกมใหม่หรือไม่? เซฟเดิมจะยังอยู่จนกว่าจะบันทึกทับ"))return;state={map:"village",player:{x:9,y:8,hp:30,max:30,level:1,xp:0,coins:10,potions:3,captureBalls:5},team:[freshMonster("Drakie"),freshMonster("Flammy"),freshMonster("Leafy")],active:null,inventory:{herb:0,crystal:0,potion:3},opened:[],quests:{herbs:{accepted:false,done:false},catch:{accepted:false,done:false},battle:{accepted:false,done:false},forest:{accepted:false,done:false}},stats:{caught:0,won:0},steps:0};state.active=state.team[0].uid;render();draw();say("เริ่มเกมใหม่แล้ว")}
document.querySelectorAll("[data-dir]").forEach(b=>b.addEventListener("click",()=>{let d=b.dataset.dir;move(d==="left"?-1:d==="right"?1:0,d==="up"?-1:d==="down"?1:0)}));
window.addEventListener("keydown",e=>{let k=e.key.toLowerCase();if(["arrowup","arrowdown","arrowleft","arrowright"].includes(k))e.preventDefault();if(["arrowup","w"].includes(k))move(0,-1);else if(["arrowdown","s"].includes(k))move(0,1);else if(["arrowleft","a"].includes(k))move(-1,0);else if(["arrowright","d"].includes(k))move(1,0)});
byId("interact").onclick=interact;byId("attack").onclick=attack;byId("catch").onclick=catchEnemy;byId("battlePotion").onclick=usePotionBattle;byId("switchBattle").onclick=switchBattle;byId("run").onclick=run;byId("teamSwitch").onclick=switchTeam;byId("healTeam").onclick=healTeam;byId("usePotion").onclick=()=>usePotion(false);byId("useCapture").onclick=buyBall;byId("save").onclick=save;byId("load").onclick=load;
document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".tab-content").forEach(x=>x.classList.toggle("hidden",x.id!==b.dataset.tab))});
try{let raw=localStorage.getItem(SAVE_KEY);if(raw)load();else{render();draw()}}catch(e){render();draw()}
})();