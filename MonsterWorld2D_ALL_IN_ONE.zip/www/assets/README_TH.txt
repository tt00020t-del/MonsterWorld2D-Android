MonsterWorld2D — Asset Library (จัดหมวดหมู่แล้ว)
================================================

โฟลเดอร์ภายใน www/assets/:
- Tileset/      ไทล์พื้นและ tileset รวม รวมไฟล์ tileset_16x16_legacy.png ที่เก็บสำรองจากโปรเจกต์เดิม
- Background/   ฉากหลังกลางวัน/พระอาทิตย์ตก/กลางคืน
- Items/        หีบ เหรียญ อัญมณี หัวใจ ยา กุญแจ และ sprite sheet
- Weapons/      ดาบและ sprite sheet
- Effects/      เอฟเฟกต์ฟัน/เวทและ sprite sheet
- UI/           ปุ่มและไอคอนหน้าจอ
- Characters/   ตัวละครผู้เล่นและท่าทางต่าง ๆ
- Monsters/     มอนสเตอร์ Slime และ Bat
- Bosses/       บอส Fire Demon
- Props/        วัตถุประกอบฉาก เช่น ต้นไม้

ไฟล์ PNG เป็น pixel art สำหรับต้นแบบ; sprite sheet ส่วนใหญ่เรียงเฟรมแนวนอน เฟรมละ 64x64 px.
manifest.json ระบุขนาดและโหมดสีของไฟล์ PNG ทุกไฟล์ใน assets/.

การเชื่อมต่อในเกม: www/assets.js โหลดรูปจากโฟลเดอร์เหล่านี้ และมี procedural fallback หากโหลดรูปไม่ได้.
ไฟล์ tileset_16x16.png ที่ราก www/ ยังคงเก็บไว้เพื่อความเข้ากันได้กับโค้ดเดิม.
ชุดนี้ยังต้องทดสอบบนอุปกรณ์จริงและสร้าง APK ผ่าน GitHub Actions ก่อนยืนยันการทำงานครบถ้วน.
