MonsterWorld2D — ขั้นที่ 3: นำ Asset เข้าเกม

สิ่งที่เชื่อมกับ HTML5 Canvas/JavaScript:
- Tileset: drawTile เลือก PNG สำหรับ grass/path/sand/stone/water/lava และ fallback เป็น procedural canvas เมื่อภาพยังโหลดไม่เสร็จหรือโหลดไม่ได้
- Background: ฉากต่อสู้เลือก bg_day / bg_sunset / bg_night ตามแผนที่; ใช้ฉาก Canvas เดิมเป็น fallback
- Characters/Monsters/Props: player, slime, blue slime, fire slime, bat และ tree โหลดจาก PNG; ตัวละคร/มอนสเตอร์ที่ไม่มีภาพเฉพาะยังใช้ procedural fallback
- Items: หีบในแผนที่ใช้ Items/chest.png; รายการคลังแสดงไอคอน PNG ของ coin/potion/herb/crystal/key
- Weapons/Effects: ดาบและเอฟเฟกต์ฟันแสดงในฉากต่อสู้เป็น visual accent
- UI: ไอคอนในรายการคลังใช้ HTML img และ CSS pixelated rendering

ข้อจำกัดที่ควรทราบ:
- ภาพบางชนิดเป็น starter assets; herb ใช้ gem เป็นภาพแทน และ battle effect เป็น visual accent, ไม่ได้ผูกกับ hitbox/damage timing.
- Background PNG อาจโหลดหลังเฟรมแรก; ระบบมี fallback แต่ยังควรทดสอบจริงใน browser/Android WebView.
- การตรวจ node --check ยืนยันเฉพาะ syntax ไม่ใช่การทดสอบการเล่นจริงหรือการ build APK.

ทดสอบเบื้องต้น:
1. เปิด www/index.html ผ่าน server หรือ GitHub Pages preview (ไม่ควรเปิด file:// หาก browser จำกัด local assets)
2. ตรวจแผนที่ หมู่บ้าน/ทุ่งหญ้า/ป่าลึก, หีบ, inventory และเริ่มการต่อสู้
3. ตรวจ console ว่าไม่มี 404 สำหรับ assets/ และไม่มี JavaScript exception
4. Build APK ผ่าน GitHub Actions และติดตั้งทดสอบบน Android
