ไฟล์เกมจริงอยู่ใน www/ ได้แก่ index.html, style.css, assets.js, game.js และ tileset_16x16.png
แพ็กเกจนี้จัดเตรียมเพื่อสร้าง Android app ด้วย Capacitor; ยังต้องสร้างโฟลเดอร์ android/ และ build APK ตาม README_BUILD_ANDROID_TH.txt
