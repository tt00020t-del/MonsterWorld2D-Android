สร้าง APK ผ่าน GitHub Actions โดยใช้มือถือ Android

1) สมัคร/เข้าสู่ระบบ GitHub แล้วสร้าง repository ใหม่ เช่น MonsterWorld2D-Android
2) แตก ZIP นี้ก่อน หากมือถือแตกไฟล์ไม่ได้ ใช้แอปจัดการไฟล์ที่รองรับ ZIP
3) อัปโหลดเนื้อหาทั้งหมดภายในโฟลเดอร์ MonsterWorld2D_Android_Build_Kit ไปที่ root ของ repository (ต้องให้ package.json อยู่ root ไม่ใช่ซ้อนอีกชั้น)
4) ตรวจสอบว่าไฟล์ .github/workflows/android.yml ถูกอัปโหลดด้วย โฟลเดอร์ที่ขึ้นต้นด้วยจุดอาจซ่อนอยู่ในแอปจัดการไฟล์
5) เปิดแท็บ Actions ของ repository แล้วเลือก workflow “Build MonsterWorld2D Android APK”
6) กด Run workflow (หรือ commit/push ไปยัง main/master เพื่อให้ workflow ทำงานอัตโนมัติ)
7) รอ workflow เสร็จเป็นสีเขียว จากนั้นเปิด run นั้นแล้วเลื่อนลงส่วน Artifacts
8) ดาวน์โหลด MonsterWorld2D-debug-apk.zip แล้วแตกไฟล์เพื่อรับ app-debug.apk
9) เปิด APK บนมือถือเพื่อติดตั้ง หากมีคำเตือน ให้อนุญาตติดตั้งจากแหล่งที่ใช้ดาวน์โหลดเฉพาะเมื่อคุณเชื่อถือไฟล์นั้น

ข้อควรทราบ:
- GitHub Actions ต้องเปิดใช้งานใน repository และมีสิทธิ์เรียกใช้งาน workflow
- ไฟล์นี้สร้าง debug APK สำหรับทดสอบ ไม่ใช่ signed release APK สำหรับเผยแพร่ Play Store
- การสร้าง APK บนคลาวด์อาจใช้เวลาหลายนาที และอาจล้มเหลวหาก dependency หรือ Android SDK เปลี่ยนแปลง
- อย่าอัปโหลด secrets หรือรหัสผ่านลง repository
