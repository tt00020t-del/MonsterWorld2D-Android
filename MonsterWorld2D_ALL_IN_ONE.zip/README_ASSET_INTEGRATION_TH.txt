MonsterWorld2D — Asset integration and Android cloud build

สิ่งที่ทำ:
- คัดลอกชุด PNG ไปที่ www/assets/
- assets.js โหลด PNG แบบ asynchronous พร้อม procedural fallback หากภาพโหลดไม่ได้
- ใช้ player sheet, slime sheets, tree และ tiles ที่มีให้ในชุด
- เก็บ tileset_16x16.png เดิมไว้
- Workflow GitHub Actions สร้าง debug APK และอัปโหลดเป็น artifact

ข้อจำกัด:
- นี่คือการผสานเบื้องต้น ยังไม่ใช่การทดสอบเกมบนอุปกรณ์จริง
- เฟรม player sheet ถูกย่อให้เข้ากับตัวละครเดิม 16x20 จึงอาจมีการสูญเสียรายละเอียด
- NPC, rock, bridge, flowers และบางชนิดมอนสเตอร์ยังใช้ภาพ procedural fallback
- ฉากหลัง PNG มีไว้ใน assets แต่ยังไม่ได้วาดเป็น parallax ใน gameplay
- ยังไม่มี APK จนกว่า GitHub Actions จะรันผ่านและมี artifact app-debug.apk

ดู README_GITHUB_BUILD_TH.txt สำหรับขั้นตอนอัปโหลด repository และเรียก workflow ผ่านมือถือ Android


จัดหมวดหมู่ asset เพิ่มเติม: www/assets/{Tileset,Background,Items,Weapons,Effects,UI,Characters,Monsters,Bosses,Props}/ และอัปเดตเส้นทางโหลดใน www/assets.js แล้ว
